 <script src="{{asset('assets/libs/bootstrap/bootstrap.min.js')}}"></script>
 <script src="{{asset('assets/libs/metismenu/metismenu.min.js')}}"></script>
 <script src="{{asset('assets/libs/simplebar/simplebar.min.js')}}"></script>
 <!-- <script src="{{asset('assets/libs/node-waves/node-waves.min.js')}}"></script> -->


 <!-- DataTables -->

 <!-- Required datatable js -->
 <script src="{{asset('assets/libs/datatables/datatables.min.js')}}"></script>
 <!-- <script src="{{asset('assets/libs/jszip/jszip.min.js')}}"></script> -->
 <!-- <script src="{{asset('assets/libs/pdfmake/pdfmake.min.js')}}"></script> -->
 <!-- Datatable init js -->
 <script src="{{asset('assets/js/pages/datatables.init.js')}}"></script>
 <!-- <script src="{{asset('assets/js/app.min.js')}}"></script> -->
 <script src="{{asset('assets/libs/select2/select2.min.js')}}"></script>
 <script>
     $('.select2').select2();

 </script>
