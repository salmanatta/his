
<?php

if (!function_exists('calc')) {
	function calc()
	{
		echo "working";
	}
}

?>