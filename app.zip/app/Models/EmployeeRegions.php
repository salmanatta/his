<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeRegions extends Model
{
//    protected $table="stock_adjustments";
    protected $guarded = [];
    use HasFactory;
}
