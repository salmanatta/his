@extends('layouts.main')
@section('content')
<div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4">Product Update </h4>
<form  class="" method="post" action="{{route('products.update',$product->id)}}">
                    	@csrf
                        @method('PUT')

                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom01" class="form-label">Product Name</label>
                                    <input type="text" name="name" value="{{$product->name}}" class="form-control" id="validationCustom01"
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                         <!--    <div class="col-md-4">
                            <div class="mb-3">
                             <label for="validationCustom01" class="form-label">Group</label>
                             <select class="form-select" required="true" name="group_id">
                                <option selected value="">--Choose Group--</option>
                                foreach($groups as $group)
                                if($group->id==$product->group)
                                        <option value="$group->id" selected="">$group->name</option>
                                        else
                                        <option value="$group->id" selected="">$group->name</option>
                                        endif
                                        endforeach
                              </select>
                                 
                                </div>
                            </div> -->
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom02" class="form-label">Short Name</label>
                                    <input type="text" value="{{$product->short_name}}" class="form-control" id="validationCustom02" name="short_name" 
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        

                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom02" class="form-label">Genral Name</label>
                                    <input type="text" class="form-control" id="validationCustom02" value="{{$product->genral_name}}" name="genral_name" 
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom01" class="form-label">Sale Price </label>
                                    <input type="text"  value="{{$product->sale_price}}" name="sale_price" class="form-control" id="validationCustom01" 
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom02" class="form-label">Purchase Price</label>
                                    <input type="text" value="{{$product->purchase_price}}" class="form-control" id="validationCustom02" name="purchase_price" 
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                             <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom01" class="form-label">Max Sale Discount</label>
                                    <input type="text" value="{{$product->max_sale_disc}}" name="max_sale_disc" class="form-control" id="validationCustom01" 
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom01" class="form-label">Sale Tax Value </label>
                                    <input type="text" value="{{$product->sale_tax_value}}" name="sale_tax_value" class="form-control" id="validationCustom01" 
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom02" class="form-label">Tax3 Type</label>
                                    <input type="text" value="{{$product->tax3_type}}" class="form-control"  name="tax3_type" 
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom02" class="form-label">Purchase Tax Value</label>
                                    <input type="text" class="form-control"  value="{{$product->purchase_tax_value}}" name="purchase_tax_value" 
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom01" class="form-label">Tax3 Value </label>
                                    <input type="text" value="{{$product->tax3_value}}" name="tax3_value" class="form-control" required >
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom02" class="form-label">Purchase Disc Value</label>
                                    <input type="text" value="{{$product->purchase_disc_value}}" class="form-control" id="validationCustom02" name="purchase_disc_value" placeholder=" purchase_disc_value"
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                        </div>

                         <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom01" class="form-label">Re Order Level </label>
                                    <input type="text"  value="{{$product->re_order_level}}" name="re_order_level" class="form-control"  
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom01" class="form-label">Trade Price </label>
                                    <input type="text" value="{{$product->trade_price}}" name="trade_price" class="form-control" 
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="validationCustom02" class="form-label">Prod Shel Life Day</label>
                                    <input type="text" value="{{$product->prod_shel_life_day}}" class="form-control"  name="prod_shel_life_day" 
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                        </div>
                            <button class="btn btn-primary"  type="submit">Update</button>
                        </div>
                    </form>
                    </div>
                <!-- end card body -->
            </div>
            <!-- end card -->
        </div>
        <!-- end col -->

       
    </div>
    <!-- end row -->

@endsection
@push('script')
    
@endpush