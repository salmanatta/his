<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title> <?php echo $__env->yieldContent('title'); ?> | <?php echo e(env('app_name')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  


    

  <link href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet">
  <link href="<?php echo e(asset('assets/images/favicon.ico')); ?>" rel="shortcut icon">
  <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(asset('assets/libs/toastr/toastr.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(asset('assets/css/toastr.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('assets/css/app.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(asset('assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(asset('assets/libs/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
  

  
  <!-- <link href="<?php echo e(asset('assets/css/jstree.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" /> -->
  <!-- <link href="<?php echo e(asset('assets/css/ext-component-tree.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" /> -->
</head>

<?php $__env->startSection('body'); ?>
    
    <body data-topbar="dark" data-layout="horizontal">
    
<?php echo $__env->yieldSection(); ?>

    <!-- Begin page -->
     <div id="layout-wrapper">
        <?php echo $__env->make('layouts.horizontal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            <div class="page-content">
                <!-- Start content -->
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div> 
                <!-- content -->
            </div>
           
                <!-- End Page-content -->
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- ============================================================== -->
        <!-- End Right content here -->
        <!-- ============================================================== -->
    </div>
    <!-- END wrapper -->

    <!-- JAVASCRIPT -->

    

<script src="<?php echo e(asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/bootstrap/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/metismenu/metismenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/datatables.init.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/dashboard.init.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/node-waves.min.js')); ?>"></script>


 <!-- <script src="<?php echo e(asset('assets/js/jstree.min.js')); ?>"></script> -->
<script src="<?php echo e(asset('assets/js/ext-component-tree.min.js')); ?>"></script>
<script>
$('.select2').select2();
</script>
<!--  Start this js use date packr to restrict user select specific dat -->
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
  function disableDate() {
    // alert('For Three Days Plan');
    $("#datepickercustom").datepicker({
    minDate: -3,
    maxDate: "+3D"
  });
  // Also, keep in mind, use mm/dd/yy format.
 }
 function disableDateFive() {
  // alert('For Five Days Plan');
//   $("#datepickercustom").datepicker({
//    minDate: -5,
//    maxDate: "+5D"
// });
}

 function disableDateSeven() {
  // alert('For Seven Days Plan');
//   $("#datepickercustom").datepicker({
//    minDate: -7,
//    maxDate: "+7D"
// });
  // window.location.reload();
  // Also, keep in mind, use mm/dd/yy format.
 }
</script>
<script >  
  <?php if(Session::has('error')): ?>
  toastr.options =
  {
    "closeButton" : true,
    "progressBar" : true
  }
        toastr.error("<?php echo e(session('error')); ?>");
  <?php endif; ?>

  <?php if(Session::has('info')): ?>
  toastr.options =
  {
    "closeButton" : true,
    "progressBar" : true
  }
        toastr.info("<?php echo e(session('info')); ?>");
  <?php endif; ?>
  <?php if(Session::has('success')): ?>
  toastr.options =
  {
    "closeButton" : true,
    "progressBar" : true
  }
        toastr.success("<?php echo e(session('success')); ?>");
  <?php endif; ?>
    </script>

    <?php echo $__env->yieldPushContent('script'); ?>
</body>
   

</html>
<?php /**PATH D:\xampp\htdocs\his\resources\views/layouts/main.blade.php ENDPATH**/ ?>