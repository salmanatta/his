<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StockAdjustmentDetailController extends Controller
{
    //
}
